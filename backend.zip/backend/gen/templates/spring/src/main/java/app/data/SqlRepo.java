package app.data;

import app.core.Entity;
import app.core.Field;
import app.core.ListQuery;
import app.core.Schema;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

/** SQL storage (SQLite, PostgreSQL, MySQL, SQL Server) on JdbcTemplate. Every value is a bound parameter; table and column names come only from schema.json
 *  and are checked against a strict pattern at start-up. */
@Component
public class SqlRepo implements Repo {
    private static final Pattern IDENT = Pattern.compile("^[A-Za-z_][A-Za-z0-9_]{0,63}$");
    private final JdbcTemplate jdbc;
    private final String db;

    public SqlRepo(JdbcTemplate jdbc, Schema schema) {
        this.jdbc = jdbc;
        this.db = schema.db();
        for (Entity e : schema.entities().values()) {
            check(e.table());
            e.fields().forEach(f -> check(f.name()));
        }
    }

    private static void check(String n) {
        if (!IDENT.matcher(n).matches()) throw new IllegalStateException("schema.json has an unsafe table or column name");
    }

    private String qn(String n) {
        return switch (db) { case "mysql" -> "`" + n + "`"; case "mssql" -> "[" + n + "]"; default -> "\"" + n + "\""; };
    }

    private static Field field(Entity e, String name) {
        return e.fields().stream().filter(f -> f.name().equals(name)).findFirst().orElse(null);
    }

    @Override public Object parseId(Object raw) {
        String s = String.valueOf(raw);
        if (!s.matches("[0-9]{1,10}")) return null;
        long n = Long.parseLong(s);
        return n > 0 && n <= 2147483647L ? (Object) n : null;
    }

    // ---- value conversion ------------------------------------------------------------------------------------------------------------
    private Object toDb(Field f, Object v) {
        if (v == null || f == null) return v;
        return switch (f.type()) {
            case "bool" -> "postgresql".equals(db) ? (Object) Boolean.valueOf(Boolean.TRUE.equals(v)) : (Object) (Boolean.TRUE.equals(v) ? 1 : 0);
            case "datetime" -> "sqlite".equals(db) ? Instant.parse(String.valueOf(v)).toString() : LocalDateTime.ofInstant(Instant.parse(String.valueOf(v)), ZoneOffset.UTC);
            default -> v;
        };
    }

    static String iso(Object v) {
        if (v instanceof Timestamp t) return t.toLocalDateTime().toInstant(ZoneOffset.UTC).toString();
        if (v instanceof LocalDateTime t) return t.toInstant(ZoneOffset.UTC).toString();
        if (v instanceof OffsetDateTime t) return t.toInstant().toString();
        if (v instanceof java.util.Date d) return d.toInstant().toString();
        String s = String.valueOf(v).trim().replace(' ', 'T');
        try { return Instant.parse(s).toString(); } catch (RuntimeException e1) { /* try the next shape */ }
        try { return OffsetDateTime.parse(s).toInstant().toString(); } catch (RuntimeException e2) { /* try the next shape */ }
        return LocalDateTime.parse(s).toInstant(ZoneOffset.UTC).toString();
    }

    private Object fromDb(Field f, Object v) {
        if (v == null) return null;
        return switch (f.type()) {
            case "bool" -> v instanceof Boolean b ? b : (Object) (((Number) v).intValue() != 0);
            case "datetime" -> iso(v);
            case "int", "ref" -> ((Number) v).longValue();
            case "float" -> ((Number) v).doubleValue();
            default -> v;
        };
    }

    private Map<String, Object> shape(Entity e, Map<String, Object> r, boolean raw) {
        if (r == null) return null;
        Map<String, Object> o = new LinkedHashMap<>();
        o.put("id", ((Number) r.get("id")).longValue());
        for (Field f : e.fields()) {
            if (!raw && e.sensitive().contains(f.name())) continue;
            if (r.containsKey(f.name())) o.put(f.name(), fromDb(f, r.get(f.name())));
        }
        return o;
    }

    // ---- queries ---------------------------------------------------------------------------------------------------------------------
    private void eq(Entity e, Map<String, Object> m, List<String> conds, List<Object> args) {
        for (var en : m.entrySet()) {
            Field f = field(e, en.getKey());
            if (f == null && !en.getKey().equals("id")) throw new IllegalArgumentException("unknown column");
            conds.add(qn(en.getKey()) + " = ?");
            args.add(toDb(f, en.getValue()));
        }
    }

    @Override public Map<String, Object> get(Entity e, Object id, boolean raw) {
        List<Map<String, Object>> r = jdbc.queryForList("SELECT * FROM " + qn(e.table()) + " WHERE " + qn("id") + " = ?", id);
        return r.isEmpty() ? null : shape(e, r.get(0), raw);
    }

    @Override public Map<String, Object> findOne(Entity e, Map<String, Object> where, boolean raw) {
        List<String> conds = new ArrayList<>();
        List<Object> args = new ArrayList<>();
        eq(e, where, conds, args);
        List<Map<String, Object>> r = jdbc.queryForList("SELECT * FROM " + qn(e.table()) + (conds.isEmpty() ? "" : " WHERE " + String.join(" AND ", conds)), args.toArray());
        return r.isEmpty() ? null : shape(e, r.get(0), raw);
    }

    @Override public Page list(Entity e, Map<String, Object> where, ListQuery q) {
        List<String> conds = new ArrayList<>();
        List<Object> args = new ArrayList<>();
        eq(e, where, conds, args);
        eq(e, q.filters(), conds, args);
        if (q.q() != null && !e.searchable().isEmpty()) {
            List<String> ors = new ArrayList<>();
            String pat = "%" + q.q().toLowerCase().replaceAll("[!%_]", "!$0") + "%";
            for (String s : e.searchable()) { ors.add("LOWER(" + qn(s) + ") LIKE ? ESCAPE '!'"); args.add(pat); }
            conds.add("(" + String.join(" OR ", ors) + ")");
        }
        String w = conds.isEmpty() ? "" : " WHERE " + String.join(" AND ", conds);
        Long total = jdbc.queryForObject("SELECT COUNT(*) FROM " + qn(e.table()) + w, Long.class, args.toArray());
        String order = " ORDER BY " + qn(q.sort().field()) + (q.sort().desc() ? " DESC" : " ASC") + (q.sort().field().equals("id") ? "" : ", " + qn("id") + " DESC");
        long offset = (long) (q.page() - 1) * q.limit();
        List<Object> a2 = new ArrayList<>(args);
        boolean ms = db.equals("mssql");
        a2.add(ms ? offset : q.limit());
        a2.add(ms ? q.limit() : offset);
        String paging = ms ? " OFFSET ? ROWS FETCH NEXT ? ROWS ONLY" : " LIMIT ? OFFSET ?";
        List<Map<String, Object>> rows = jdbc.queryForList("SELECT * FROM " + qn(e.table()) + w + order + paging, a2.toArray());
        return new Page(rows.stream().map(r -> shape(e, r, false)).toList(), total == null ? 0 : total);
    }

    @Override public Map<String, Object> create(Entity e, Map<String, Object> data) {
        List<String> cols = new ArrayList<>(), marks = new ArrayList<>();
        List<Object> args = new ArrayList<>();
        for (Field f : e.fields()) {
            if (!data.containsKey(f.name())) continue;
            cols.add(qn(f.name()));
            marks.add("?");
            args.add(toDb(f, data.get(f.name())));
        }
        String sql = "INSERT INTO " + qn(e.table()) + (cols.isEmpty() ? (db.equals("mysql") ? " () VALUES ()" : " DEFAULT VALUES")
                : " (" + String.join(", ", cols) + ") VALUES (" + String.join(", ", marks) + ")");
        KeyHolder kh = new GeneratedKeyHolder();
        jdbc.update(con -> {
            var ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            for (int i = 0; i < args.size(); i++) ps.setObject(i + 1, args.get(i));
            return ps;
        }, kh);
        Map<String, Object> keys = kh.getKeys();
        Object id = keys == null ? null : keys.get("id");
        if (id == null && keys != null) id = keys.values().stream().filter(Number.class::isInstance).findFirst().orElse(null);
        if (id == null) throw new IllegalStateException("the database did not return the new id");
        return get(e, ((Number) id).longValue(), false);
    }

    @Override public Map<String, Object> update(Entity e, Object id, Map<String, Object> data) {
        List<String> sets = new ArrayList<>();
        List<Object> args = new ArrayList<>();
        for (Field f : e.fields()) {
            if (!data.containsKey(f.name())) continue;
            sets.add(qn(f.name()) + " = ?");
            args.add(toDb(f, data.get(f.name())));
        }
        if (!sets.isEmpty()) {
            args.add(id);
            jdbc.update("UPDATE " + qn(e.table()) + " SET " + String.join(", ", sets) + " WHERE " + qn("id") + " = ?", args.toArray());
        }
        return get(e, id, false);
    }

    @Override public boolean remove(Entity e, Object id) {
        return jdbc.update("DELETE FROM " + qn(e.table()) + " WHERE " + qn("id") + " = ?", id) > 0;
    }

    @Override public int removeWhere(Entity e, Map<String, Object> where) {
        List<String> conds = new ArrayList<>();
        List<Object> args = new ArrayList<>();
        eq(e, where, conds, args);
        return jdbc.update("DELETE FROM " + qn(e.table()) + (conds.isEmpty() ? "" : " WHERE " + String.join(" AND ", conds)), args.toArray());
    }
}
