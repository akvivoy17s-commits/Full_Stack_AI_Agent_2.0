package app.data;

import app.core.Entity;
import app.core.Field;
import app.core.ListQuery;
import app.core.Schema;
import jakarta.annotation.PostConstruct;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

/** MongoDB storage. Collection = table name from schema.json. Optional values that are null are not stored (so sparse unique indexes work). */
@Component
public class MongoRepo implements Repo {
    private final MongoTemplate mongo;
    private final Schema schema;

    public MongoRepo(MongoTemplate mongo, Schema schema) {
        this.mongo = mongo;
        this.schema = schema;
    }

    @PostConstruct
    void indexes() {
        for (Entity e : schema.entities().values()) {
            for (Field f : e.fields()) {
                if (f.unique()) mongo.indexOps(e.table()).ensureIndex(new Index().on(f.name(), Sort.Direction.ASC).unique().sparse());
                else if (f.index()) mongo.indexOps(e.table()).ensureIndex(new Index().on(f.name(), Sort.Direction.ASC));
            }
        }
    }

    @Override public Object parseId(Object raw) {
        String s = String.valueOf(raw);
        return ObjectId.isValid(s) && s.length() == 24 ? s : null;
    }

    private static Object toDb(Field f, Object v) {
        return f != null && f.type().equals("datetime") && v != null ? Date.from(Instant.parse(String.valueOf(v))) : v;
    }

    private Map<String, Object> shape(Entity e, Document d, boolean raw) {
        if (d == null) return null;
        Map<String, Object> o = new LinkedHashMap<>();
        o.put("id", d.getObjectId("_id").toHexString());
        for (Field f : e.fields()) {
            if (!raw && e.sensitive().contains(f.name())) continue;
            if (!d.containsKey(f.name())) { if (!f.required()) o.put(f.name(), null); continue; }
            Object v = d.get(f.name());
            o.put(f.name(), v instanceof Date dt ? dt.toInstant().toString() : v instanceof Number n && f.type().equals("int") ? (Object) n.longValue() : v);
        }
        return o;
    }

    private Criteria where(Entity e, Map<String, Object> m, Criteria... more) {
        List<Criteria> all = new ArrayList<>();
        for (var en : m.entrySet()) all.add(Criteria.where(en.getKey().equals("id") ? "_id" : en.getKey()).is(en.getKey().equals("id") ? new ObjectId(String.valueOf(en.getValue())) : toDb(field(e, en.getKey()), en.getValue())));
        all.addAll(List.of(more));
        return all.isEmpty() ? new Criteria() : new Criteria().andOperator(all.toArray(new Criteria[0]));
    }

    private static Field field(Entity e, String n) { return e.fields().stream().filter(f -> f.name().equals(n)).findFirst().orElse(null); }

    @Override public Map<String, Object> get(Entity e, Object id, boolean raw) {
        return shape(e, mongo.findOne(new Query(Criteria.where("_id").is(new ObjectId(String.valueOf(id)))), Document.class, e.table()), raw);
    }

    @Override public Map<String, Object> findOne(Entity e, Map<String, Object> w, boolean raw) {
        return shape(e, mongo.findOne(new Query(where(e, w)), Document.class, e.table()), raw);
    }

    @Override public Page list(Entity e, Map<String, Object> w, ListQuery q) {
        Criteria[] extra = new Criteria[0];
        if (q.q() != null && !e.searchable().isEmpty()) {
            Pattern p = Pattern.compile(Pattern.quote(q.q()), Pattern.CASE_INSENSITIVE);
            extra = new Criteria[] {new Criteria().orOperator(e.searchable().stream().map(s -> Criteria.where(s).regex(p)).toArray(Criteria[]::new))};
        }
        Criteria c = where(e, new LinkedHashMap<>(merge(w, q.filters())), extra);
        long total = mongo.count(new Query(c), e.table());
        String sf = q.sort().field().equals("id") ? "_id" : q.sort().field();
        Sort sort = Sort.by(q.sort().desc() ? Sort.Direction.DESC : Sort.Direction.ASC, sf);
        if (!sf.equals("_id")) sort = sort.and(Sort.by(Sort.Direction.DESC, "_id"));
        Query query = new Query(c).with(sort).skip((long) (q.page() - 1) * q.limit()).limit(q.limit());
        return new Page(mongo.find(query, Document.class, e.table()).stream().map(d -> shape(e, d, false)).toList(), total);
    }

    private static Map<String, Object> merge(Map<String, Object> a, Map<String, Object> b) {
        Map<String, Object> m = new LinkedHashMap<>(a);
        m.putAll(b);
        return m;
    }

    @Override public Map<String, Object> create(Entity e, Map<String, Object> data) {
        Document d = new Document();
        for (Field f : e.fields()) if (data.get(f.name()) != null) d.put(f.name(), toDb(f, data.get(f.name())));
        mongo.insert(d, e.table());
        return shape(e, d, false);
    }

    @Override public Map<String, Object> update(Entity e, Object id, Map<String, Object> data) {
        Update u = new Update();
        boolean any = false;
        for (Field f : e.fields()) {
            if (!data.containsKey(f.name())) continue;
            any = true;
            if (data.get(f.name()) == null) u.unset(f.name()); else u.set(f.name(), toDb(f, data.get(f.name())));
        }
        if (any) mongo.updateFirst(new Query(Criteria.where("_id").is(new ObjectId(String.valueOf(id)))), u, e.table());
        return get(e, id, false);
    }

    @Override public boolean remove(Entity e, Object id) {
        return mongo.remove(new Query(Criteria.where("_id").is(new ObjectId(String.valueOf(id)))), e.table()).getDeletedCount() > 0;
    }

    @Override public int removeWhere(Entity e, Map<String, Object> w) {
        return (int) mongo.remove(new Query(where(e, w)), e.table()).getDeletedCount();
    }
}
