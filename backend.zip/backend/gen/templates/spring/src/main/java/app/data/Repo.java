package app.data;

import app.core.Entity;
import app.core.ListQuery;
import java.util.List;
import java.util.Map;

/** Storage port. Same behaviour for SQL and MongoDB. Ids are Long (SQL) or hex String (MongoDB). Maps hold API-shaped values. */
public interface Repo {
    record Page(List<Map<String, Object>> rows, long total) {}

    Object parseId(Object raw);
    Map<String, Object> get(Entity e, Object id, boolean raw);
    Map<String, Object> findOne(Entity e, Map<String, Object> where, boolean raw);
    Page list(Entity e, Map<String, Object> where, ListQuery q);
    Map<String, Object> create(Entity e, Map<String, Object> data);
    Map<String, Object> update(Entity e, Object id, Map<String, Object> data);
    boolean remove(Entity e, Object id);
    int removeWhere(Entity e, Map<String, Object> where);
}
