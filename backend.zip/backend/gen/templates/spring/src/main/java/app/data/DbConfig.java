package app.data;

import app.core.Schema;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Builds the connection pool from DATABASE_URL (e.g. postgresql://user:pass@host:5432/db, sqlite:///./app.db). The URL is never logged. */
@Configuration
public class DbConfig {
    private static String dec(String s) { return URLDecoder.decode(s, StandardCharsets.UTF_8); }

    static String jdbcUrl(String kind, String url, boolean ssl) {
        if (kind.equals("sqlite")) {
            String p = url.replaceFirst("^sqlite:/{2,3}", "");
            return "jdbc:sqlite:" + (p.isEmpty() ? ":memory:" : p) + (p.contains("?") ? "&" : "?") + "foreign_keys=on";
        }
        URI u = URI.create(url);
        if (u.getHost() == null) throw new IllegalStateException("DATABASE_URL needs a host");
        String name = u.getPath() == null ? "" : u.getPath().replaceFirst("^/", "");
        int port = u.getPort();
        return switch (kind) {
            case "postgresql" -> "jdbc:postgresql://" + u.getHost() + ":" + (port > 0 ? port : 5432) + "/" + name + (ssl ? "?sslmode=require" : "");
            case "mysql" -> "jdbc:mysql://" + u.getHost() + ":" + (port > 0 ? port : 3306) + "/" + name + "?connectionTimeZone=UTC&forceConnectionTimeZoneToSession=true&useUnicode=true&characterEncoding=utf8"
                    + (ssl ? "&sslMode=REQUIRED" : "");
            case "mssql" -> "jdbc:sqlserver://" + u.getHost() + ":" + (port > 0 ? port : 1433) + ";databaseName=" + name + ";encrypt=" + ssl + ";trustServerCertificate=" + !ssl;
            default -> throw new IllegalStateException("Unsupported database " + kind);
        };
    }

    @Bean(destroyMethod = "close")
    DataSource dataSource(Schema schema, @Value("${DATABASE_URL:}") String url, @Value("${DATABASE_SSL:false}") boolean ssl) {
        if (url.isBlank()) throw new IllegalStateException("DATABASE_URL is not set (see .env.example)");
        HikariConfig c = new HikariConfig();
        try {
            c.setJdbcUrl(jdbcUrl(schema.db(), url, ssl));
            if (!schema.db().equals("sqlite")) {
                URI u = URI.create(url);
                String[] ui = u.getRawUserInfo() == null ? new String[0] : u.getRawUserInfo().split(":", 2);
                if (ui.length > 0) c.setUsername(dec(ui[0]));
                if (ui.length > 1) c.setPassword(dec(ui[1]));
            }
        } catch (IllegalArgumentException e) {
            throw new IllegalStateException("DATABASE_URL is not a valid URL (special characters in the password must be percent-encoded)");
        }
        c.setMaximumPoolSize(schema.db().equals("sqlite") ? 1 : 10);
        c.setPoolName("api");
        return new HikariDataSource(c);
    }
}
